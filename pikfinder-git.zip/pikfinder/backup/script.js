/**
 * PikFinder Core JavaScript
 * Features Keyless Wikimedia Integration, Auth flows, and Performance direct downloads
 */

document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');
    const imageGrid = document.getElementById('imageGrid');
    const loader = document.getElementById('loader');
    const galleryTitle = document.getElementById('galleryTitle');
    const loadMoreContainer = document.getElementById('loadMoreContainer');
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    
    // Auth Nodes
    const navAuth = document.getElementById('navAuth');
    const navUser = document.getElementById('navUser');
    const loginBtn = document.getElementById('loginBtn');
    const signupBtn = document.getElementById('signupBtn');
    const authModal = document.getElementById('authModal');
    const closeAuthModal = document.getElementById('closeAuthModal');
    const authForm = document.getElementById('authForm');
    const nameGroup = document.getElementById('nameGroup');
    const authTitle = document.getElementById('authTitle');
    const authSubtitle = document.getElementById('authSubtitle');
    const authToggleBtn = document.getElementById('authToggleBtn');
    const authToggleText = document.getElementById('authToggleText');
    const authSubmitBtn = document.getElementById('authSubmitBtn');
    
    // Modal Elements
    const imageModal = document.getElementById('imageModal');
    const closeModal = document.getElementById('closeModal');
    const modalImg = document.getElementById('modalImg');
    const photographerAvatar = document.getElementById('photographerAvatar');
    const photographerName = document.getElementById('photographerName');
    const photographerLink = document.getElementById('photographerLink');
    const downloadBtn = document.getElementById('downloadBtn');
    const modalFavBtn = document.getElementById('modalFavBtn');
    
    // Global State
    const urlParams = new URLSearchParams(window.location.search);
    const initialQuery = urlParams.get('q');
    
    let currentQuery = initialQuery ? initialQuery : 'neon dark'; 
    let currentPage = 1;
    let isFetching = false;
    let isLoggedIn = false;
    let authMode = 'signup'; // 'login' or 'signup'
    let currentPhotoContext = null;

    // --- Authentication Logic ---
    function toggleAuthMode() {
        if (authMode === 'signup') {
            authMode = 'login';
            if(nameGroup) nameGroup.style.display = 'none';
            if(authTitle) authTitle.textContent = 'Welcome Back';
            if(authSubtitle) authSubtitle.textContent = 'Sign in to access your curated collections.';
            if(authSubmitBtn) authSubmitBtn.textContent = 'Log In';
            if(authToggleText) authToggleText.textContent = "Don't have an account?";
            if(authToggleBtn) authToggleBtn.textContent = 'Sign up';
        } else {
            authMode = 'signup';
            if(nameGroup) nameGroup.style.display = 'flex';
            if(authTitle) authTitle.textContent = 'Join PikFinder';
            if(authSubtitle) authSubtitle.textContent = 'Save your favorite photos and curate your collections.';
            if(authSubmitBtn) authSubmitBtn.textContent = 'Create Account';
            if(authToggleText) authToggleText.textContent = 'Already have an account?';
            if(authToggleBtn) authToggleBtn.textContent = 'Log in';
        }
    }

    function openAuthModal() {
        if(authModal) {
            authModal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    function closeAllModals() {
        if(imageModal) imageModal.classList.remove('active');
        if(authModal) authModal.classList.remove('active');
        document.body.style.overflow = 'auto';
        currentPhotoContext = null;
    }

    // Auth Listeners
    if(loginBtn) loginBtn.addEventListener('click', () => { if(authMode !== 'login') toggleAuthMode(); openAuthModal(); });
    if(signupBtn) signupBtn.addEventListener('click', () => { if(authMode !== 'signup') toggleAuthMode(); openAuthModal(); });
    if(authToggleBtn) authToggleBtn.addEventListener('click', (e) => { e.preventDefault(); toggleAuthMode(); });
    if(closeAuthModal) closeAuthModal.addEventListener('click', closeAllModals);
    
    if(authForm) {
        authForm.addEventListener('submit', (e) => {
            e.preventDefault();
            authSubmitBtn.innerHTML = '<div class="spinner" style="width:20px;height:20px;border-width:2px;margin:0;"></div>';
            setTimeout(() => {
                isLoggedIn = true;
                navAuth.style.display = 'none';
                navUser.style.display = 'flex';
                closeAllModals();
                authSubmitBtn.textContent = authMode === 'signup' ? 'Create Account' : 'Log In';
                if(currentPhotoContext) {
                    const favBtn = currentPhotoContext.favBtn;
                    favBtn.classList.toggle('active');
                    if(favBtn.classList.contains('active')) {
                        favBtn.innerHTML = '<i class="ph-fill ph-heart"></i>';
                    } else {
                        favBtn.innerHTML = '<i class="ph ph-heart"></i>';
                    }
                }
            }, 1000);
        });
    }

    // --- Image Preview Logic ---
    if(closeModal) closeModal.addEventListener('click', closeAllModals);

    [imageModal, authModal].forEach(modal => {
        if(modal) {
            modal.addEventListener('click', (e) => {
                if(e.target === modal) closeAllModals();
            });
        }
    });

    function openImageModal(photoData, cardFavBtnRef) {
        currentPhotoContext = { data: photoData, favBtn: cardFavBtnRef };
        
        modalImg.src = photoData.urls.full;
        photographerName.textContent = photoData.user.name;
        photographerAvatar.src = photoData.user.profile_image.medium;
        
        if(cardFavBtnRef.classList.contains('active')) {
            modalFavBtn.classList.add('active');
            modalFavBtn.innerHTML = '<i class="ph-fill ph-heart"></i>';
        } else {
            modalFavBtn.classList.remove('active');
            modalFavBtn.innerHTML = '<i class="ph ph-heart"></i>';
        }

        downloadBtn.onclick = async (e) => {
            e.preventDefault();
            downloadDirectFile(photoData);
        };

        imageModal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    if(modalFavBtn) {
        modalFavBtn.addEventListener('click', () => {
            if(!isLoggedIn) {
                imageModal.classList.remove('active');
                openAuthModal();
                return;
            }
            modalFavBtn.classList.toggle('active');
            if(currentPhotoContext) {
                currentPhotoContext.favBtn.classList.toggle('active');
                const icon = modalFavBtn.classList.contains('active') ? '<i class="ph-fill ph-heart"></i>' : '<i class="ph ph-heart"></i>';
                modalFavBtn.innerHTML = icon;
                currentPhotoContext.favBtn.innerHTML = icon;
            }
        });
    }

    // --- Download Engine ---
    async function downloadDirectFile(photo) {
        const btnRefs = document.querySelectorAll(`[data-id="${photo.id}"] .download-specific, #downloadBtn`);
        btnRefs.forEach(btn => {
            const originalHTML = btn.innerHTML;
            btn.innerHTML = '<div class="spinner" style="width:20px;height:20px;border-width:2px;margin:0;"></div>';
            btn.dataset.original = originalHTML;
            btn.style.pointerEvents = 'none';
        });

        try {
            const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(photo.urls.full)}`;
            const response = await fetch(proxyUrl);
            if (!response.ok) throw new Error('Proxy blocked or network issue');
            const blob = await response.blob();
            const localObjUrl = window.URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = localObjUrl;
            const safeName = photo.alt_description.replace(/[^a-z0-9]/gi, '_').toLowerCase();
            a.download = `pikfinder-${safeName}.jpg`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(localObjUrl);
            a.remove();
        } catch (err) {
            console.warn('Fallback standard download initiated', err);
            window.open(photo.urls.full, '_blank');
        } finally {
            btnRefs.forEach(btn => {
                btn.innerHTML = btn.dataset.original;
                btn.style.pointerEvents = 'auto';
            });
        }
    }

    // --- Image Fetching & Grid Rendering ---
    async function fetchImages(query, page) {
        if (!imageGrid) return; // Guard clause for other pages
        if (isFetching) return;
        isFetching = true;
        
        if (page === 1) {
            imageGrid.innerHTML = '';
            if(galleryTitle) galleryTitle.textContent = query ? `Discovering "${query}"` : 'Fresh Discoveries';
        }
        
        if(loader) loader.style.display = 'block';
        if(loadMoreContainer) loadMoreContainer.style.display = 'none';

        try {
            const searchQuery = encodeURIComponent(`${query} filetype:bitmap`);
            const offset = (page - 1) * 12;
            const endpoint = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrsearch=${searchQuery}&gsrlimit=12&gsroffset=${offset}&prop=imageinfo&iiprop=url|user|extmetadata&iiurlwidth=600&format=json&origin=*`;
            
            const response = await fetch(endpoint);
            const data = await response.json();
            const results = [];
            
            if (data.query && data.query.pages) {
                Object.values(data.query.pages).forEach(pageObj => {
                    if (pageObj.imageinfo && pageObj.imageinfo[0]) {
                        const info = pageObj.imageinfo[0];
                        if (info.url && (info.url.endsWith('.jpg') || info.url.endsWith('.jpeg') || info.url.endsWith('.png'))) {
                            results.push({
                                id: pageObj.pageid,
                                urls: {
                                    regular: info.thumburl || info.url,
                                    full: info.url
                                },
                                alt_description: pageObj.title.replace('File:', '').replace(/\.[^/.]+$/, "").split('_').join(' '),
                                user: {
                                    name: info.extmetadata?.Artist?.value ? info.extmetadata.Artist.value.replace(/<[^>]*>?/gm, '') : (info.user || 'Wikimedia Creator'),
                                    username: info.user || 'wikimedia',
                                    profile_image: {
                                        medium: `https://api.dicebear.com/6.x/initials/svg?seed=${info.user || 'W'}`
                                    }
                                }
                            });
                        }
                    }
                });
            }

            if (results.length === 0 && page === 1) {
                imageGrid.innerHTML = `<div style="text-align:center; width:100%; grid-column:1/-1; color: var(--text-muted); padding: 60px;">No aesthetic visuals found for "${query}". Try another word!</div>`;
            } else {
                results.forEach(photo => {
                    imageGrid.appendChild(createCardElement(photo));
                });
                if (results.length > 0 && loadMoreContainer) loadMoreContainer.style.display = 'flex';
            }
        } catch (error) {
            console.error(error);
            if (page === 1) {
                imageGrid.innerHTML = `<div style="text-align:center; width:100%; grid-column:1/-1; color: #ef4444; padding: 60px;">Network aesthetic interference. Please try again.</div>`;
            }
        } finally {
            if(loader) loader.style.display = 'none';
            isFetching = false;
        }
    }

    function createCardElement(photo) {
        const div = document.createElement('div');
        div.className = 'img-card';
        div.dataset.id = photo.id;
        
        div.innerHTML = `
            <img src="${photo.urls.regular}" alt="${photo.alt_description}" loading="lazy">
            <div class="img-overlay">
                <div class="img-actions">
                    <button class="icon-btn fav-specific" title="Favorite"><i class="ph ph-heart"></i></button>
                    <a href="#" class="icon-btn download-specific" title="Direct Download"><i class="ph ph-download-simple"></i></a>
                </div>
                <div class="img-info">
                    <img src="${photo.user.profile_image.medium}" alt="${photo.user.name}">
                    <p>${photo.user.name.substring(0,20)}${photo.user.name.length > 20 ? '...' : ''}</p>
                </div>
            </div>
        `;
        
        const dlBtn = div.querySelector('.download-specific');
        const favBtn = div.querySelector('.fav-specific');

        dlBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            e.preventDefault();
            downloadDirectFile(photo);
        });

        favBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if(!isLoggedIn) {
                currentPhotoContext = { data: photo, favBtn: favBtn };
                openAuthModal();
                return;
            }
            favBtn.classList.toggle('active');
            if(favBtn.classList.contains('active')) {
                favBtn.innerHTML = '<i class="ph-fill ph-heart"></i>';
            } else {
                favBtn.innerHTML = '<i class="ph ph-heart"></i>';
            }
        });

        div.addEventListener('click', () => openImageModal(photo, favBtn));

        return div;
    }

    // --- Search Logic ---
    if(searchForm) {
        searchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const query = searchInput.value.trim();
            if (query) {
                currentQuery = query;
                currentPage = 1;
                fetchImages(currentQuery, currentPage);
                const hdr = document.querySelector('.gallery-header');
                if(hdr) hdr.scrollIntoView({ behavior: 'smooth' });
            }
        });
    }

    document.querySelectorAll('.trend-tag').forEach(tag => {
        tag.addEventListener('click', () => {
            if(searchInput) searchInput.value = tag.textContent.trim();
            currentQuery = tag.textContent.trim();
            currentPage = 1;
            fetchImages(currentQuery, currentPage);
            const hdr = document.querySelector('.gallery-header');
            if(hdr) hdr.scrollIntoView({ behavior: 'smooth' });
        });
    });

    if(loadMoreBtn) {
        loadMoreBtn.addEventListener('click', () => {
            if (!isFetching) {
                currentPage++;
                fetchImages(currentQuery, currentPage);
            }
        });
    }

    // --- Boot ---
    if(imageGrid) {
        fetchImages(currentQuery, 1);
    }
});
