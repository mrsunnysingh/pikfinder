/**
 * Pik Finder — Contact form handler (Google Apps Script)
 * ------------------------------------------------------
 * This gives you BOTH:
 *   1) An email to your configured address for every submission
 *   2) A Google Sheet (your "Excel") with one row per message, categorised
 *
 * SETUP (5 minutes, one time):
 * 1. Go to https://sheets.google.com and create a new blank spreadsheet.
 *    Name it e.g. "Pik Finder Messages".
 * 2. In that sheet: Extensions → Apps Script. Delete any sample code.
 * 3. Paste THIS entire file. Click Save.
 * 4. Click Deploy → New deployment → type "Web app".
 *      - Description: Pik Finder contact
 *      - Execute as: Me
 *      - Who has access: Anyone
 *    Click Deploy, authorise when prompted.
 * 5. Copy the "Web app URL" it gives you.
 * 6. In your project's .env file add:
 *      VITE_CONTACT_ENDPOINT=<paste the web app URL here>
 *    then rebuild: npm run build
 *
 * The sheet auto-creates a header row: Timestamp | Category | Name | Email | Message
 * Filter/sort by the Category column to see Bugs, Reviews, Suggestions, etc.
 */

// Set this to the email address that should receive contact-form submissions.
var NOTIFY_EMAIL = 'your-email@example.com';

function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents || '{}');
    var name = String(data.name || '').slice(0, 200);
    var email = String(data.email || '').slice(0, 200);
    var category = String(data.category || 'General').slice(0, 60);
    var message = String(data.message || '').slice(0, 5000);
    var when = new Date();

    // --- 1. Append a row to the spreadsheet ---
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(['Timestamp', 'Category', 'Name', 'Email', 'Message']);
      sheet.getRange(1, 1, 1, 5).setFontWeight('bold');
    }
    sheet.appendRow([when, category, name, email, message]);

    // --- 2. Email you a notification ---
    MailApp.sendEmail({
      to: NOTIFY_EMAIL,
      subject: '[Pik Finder] ' + category + ' from ' + name,
      replyTo: email || NOTIFY_EMAIL,
      body:
        'Category: ' + category + '\n' +
        'Name: ' + name + '\n' +
        'Email: ' + email + '\n' +
        'Time: ' + when + '\n\n' +
        'Message:\n' + message,
    });

    return ContentService
      .createTextOutput(JSON.stringify({ ok: true }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: String(err) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  return ContentService.createTextOutput('Pik Finder contact endpoint is live.');
}
