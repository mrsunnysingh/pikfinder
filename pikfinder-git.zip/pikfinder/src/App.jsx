import React, { useContext } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AppContext } from './context/AppContext';

// Components
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import AuthModal from './components/AuthModal';
import Cursor from './components/Cursor';
import ScrollToTop from './components/ScrollToTop';
import DashboardLayout from './components/dashboard/DashboardLayout';

// Pages
import Home from './pages/Home';
import Collections from './pages/Collections';
import Contact from './pages/Contact';
import Legal from './pages/Legal';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import License from './pages/License';
import Products from './pages/Products';
import Favorites from './pages/Favorites';
import DashboardHome from './pages/DashboardHome';
import DashboardSearch from './pages/DashboardSearch';
import BackgroundGenerator from './pages/BackgroundGenerator';
import Profile from './pages/Profile';
import DuotoneStudio from './pages/DuotoneStudio';
import GradientGenerator from './pages/GradientGenerator';
import JsonViewer from './pages/JsonViewer';
import FreeTools from './pages/FreeTools';
import Support from './pages/Support';
import Settings from './pages/Settings';
import Help from './pages/Help';

function App() {
  const { isAuthModalOpen, isLoggedIn } = useContext(AppContext);

  return (
    <Router>
      <ScrollToTop />
      <Cursor />
      <div className="bg-shape shape-1"></div>
      <div className="bg-shape shape-2"></div>
      <div className="noise-bg"></div>
      
      {!isLoggedIn ? (
        <>
          <Navbar />
          <main>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/collections" element={<Collections />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/legal" element={<Legal />} />
              <Route path="/terms" element={<Terms />} />
              <Route path="/privacy" element={<Privacy />} />
              <Route path="/license" element={<License />} />
              <Route path="/products" element={<Products />} />
              <Route path="/backgrounds" element={<BackgroundGenerator />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/duotone" element={<DuotoneStudio />} />
              <Route path="/gradient" element={<GradientGenerator />} />
              <Route path="/json" element={<JsonViewer />} />
              <Route path="/tools" element={<FreeTools />} />
              <Route path="/support" element={<Support />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/help" element={<Help />} />
              <Route path="/favorites" element={<Favorites />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>
          <Footer />
        </>
      ) : (
        <Routes>
          <Route path="/" element={<DashboardLayout />}>
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route path="dashboard" element={<DashboardHome />} />
            <Route path="search" element={<DashboardSearch />} />
            <Route path="backgrounds" element={<BackgroundGenerator />} />
            <Route path="profile" element={<Profile />} />
            <Route path="duotone" element={<DuotoneStudio />} />
            <Route path="gradient" element={<GradientGenerator />} />
            <Route path="json" element={<JsonViewer />} />
            <Route path="tools" element={<FreeTools />} />
            <Route path="support" element={<Support />} />
            <Route path="settings" element={<Settings />} />
            <Route path="help" element={<Help />} />
            <Route path="collections" element={<Collections />} />
            <Route path="favorites" element={<Favorites />} />
            <Route path="products" element={<Products />} />
            <Route path="contact" element={<Contact />} />
            <Route path="terms" element={<Terms />} />
            <Route path="privacy" element={<Privacy />} />
            <Route path="license" element={<License />} />
            <Route path="*" element={<DashboardHome />} />
          </Route>
        </Routes>
      )}

      {/* Global Modals */}
      {isAuthModalOpen && <AuthModal />}
    </Router>
  );
}

export default App;
