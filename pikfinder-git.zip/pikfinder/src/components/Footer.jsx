import React from 'react';
import { Link } from 'react-router-dom';
import { TwitterLogo, InstagramLogo, GithubLogo } from '@phosphor-icons/react';
import Logo from './Logo';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-brand">
          <div className="logo">
            <Logo size={30} />
          </div>
          <p>Empowering creators with boundless, copyright-free imagery directly integrated from global commons, all within a beautiful, modern interface.</p>
          <div className="social-links">
            <a href="https://twitter.com/pikfinder" target="_blank" rel="noopener noreferrer" title="Twitter"><TwitterLogo /></a>
            <a href="https://instagram.com/pikfinder" target="_blank" rel="noopener noreferrer" title="Instagram"><InstagramLogo /></a>
            <a href="https://github.com/mrsunnysingh/pikfinder" target="_blank" rel="noopener noreferrer" title="GitHub"><GithubLogo /></a>
          </div>
        </div>
        
        <div className="footer-links">
          <div className="link-group">
            <h4>Platform</h4>
            <Link to="/">Discover</Link>
            <Link to="/collections">Categories</Link>
            <Link to="/collections">Collections</Link>
            <Link to="/tools">Free Tools</Link>
          </div>
          <div className="link-group">
            <h4>Legal</h4>
            <Link to="/terms">Terms of Service</Link>
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/license">License Details</Link>
          </div>
          <div className="link-group">
            <h4>Connect</h4>
            <Link to="/contact">Contact Us</Link>
            <Link to="/help">Help Center</Link>
            <Link to="/legal">API Documentation</Link>
            <Link to="/support">Buy me a coffee ☕</Link>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>&copy; 2026 PikFinder. All rights reserved.</p>
      </div>
    </footer>
  );
}
