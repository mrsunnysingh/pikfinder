import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import ImageCard from './ImageCard';
import ImageModal from './ImageModal';
import FilterBar, { USAGE_KEYWORDS } from './FilterBar';

export default function Gallery({ initialQuery = 'neon dark' }) {
  const [images, setImages] = useState([]);
  const [page, setPage] = useState(1);
  const [isFetching, setIsFetching] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [filters, setFilters] = useState({ orientation: '', color: '', style: '', usage: '' });

  // Build the effective search string from the base query + augmenting filters.
  const effectiveQuery = useMemo(() => {
    const parts = [initialQuery];
    if (filters.color) parts.push(filters.color.toLowerCase());
    if (filters.style) parts.push(filters.style.toLowerCase());
    if (filters.usage && USAGE_KEYWORDS[filters.usage]) parts.push(USAGE_KEYWORDS[filters.usage]);
    return parts.filter(Boolean).join(' ').trim();
  }, [initialQuery, filters.color, filters.style, filters.usage]);

  const fetchImages = useCallback(async (searchQuery, pageNum) => {
    setIsFetching(true);

    // Query Wikimedia for a given term; returns the parsed results array.
    const queryWikimedia = async (term, offset) => {
      const q = encodeURIComponent(`${term} filetype:bitmap`);
      const endpoint = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrsearch=${q}&gsrlimit=12&gsroffset=${offset}&prop=imageinfo&iiprop=url|size|user|extmetadata&iiurlwidth=600&format=json&origin=*`;
      const response = await fetch(endpoint);
      const data = await response.json();
      const out = [];
      if (data.query && data.query.pages) {
        Object.values(data.query.pages).forEach(pageObj => {
          if (pageObj.imageinfo && pageObj.imageinfo[0]) {
            const info = pageObj.imageinfo[0];
            if (info.url && (info.url.endsWith('.jpg') || info.url.endsWith('.jpeg') || info.url.endsWith('.png'))) {
              const w = info.width || 0, h = info.height || 0;
              out.push({
                id: pageObj.pageid, width: w, height: h,
                orientation: w && h ? (w / h > 1.15 ? 'Landscape' : w / h < 0.85 ? 'Portrait' : 'Square') : 'Square',
                urls: { regular: info.thumburl || info.url, full: info.url },
                alt_description: pageObj.title.replace('File:', '').replace(/\.[^/.]+$/, "").split('_').join(' '),
                user: {
                  name: info.extmetadata?.Artist?.value ? info.extmetadata.Artist.value.replace(/<[^>]*>?/gm, '') : (info.user || 'Wikimedia Creator'),
                  username: info.user || 'wikimedia',
                  profile_image: { medium: `https://api.dicebear.com/6.x/initials/svg?seed=${info.user || 'W'}` }
                }
              });
            }
          }
        });
      }
      return out;
    };

    try {
      const offset = (pageNum - 1) * 12;
      let results = await queryWikimedia(searchQuery, offset);

      // Fallback: if a specific query returns nothing on page 1, progressively broaden it.
      if (results.length === 0 && pageNum === 1) {
        const words = searchQuery.trim().split(/\s+/);
        const broaders = [];
        if (words.length > 2) broaders.push(words.slice(0, 2).join(' '));
        if (words.length > 1) broaders.push(words[0]);
        for (const term of broaders) {
          results = await queryWikimedia(term, 0);
          if (results.length > 0) break;
        }
      }

      if (results.length === 0 && pageNum === 1) {
        setImages([]); setHasMore(false);
      } else if (results.length === 0) {
        setHasMore(false);
      } else {
        setImages(prev => pageNum === 1 ? results : [...prev, ...results]);
        setHasMore(true);
      }
    } catch (error) {
      console.error('Fetch error:', error);
    } finally {
      setIsFetching(false);
    }
  }, []);

  // Refetch from page 1 whenever the effective query changes.
  useEffect(() => {
    setPage(1);
    setImages([]);
    setHasMore(true);
    fetchImages(effectiveQuery, 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effectiveQuery]);

  // Load subsequent pages.
  useEffect(() => {
    if (page > 1) fetchImages(effectiveQuery, page);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page]);

  // Orientation is a client-side filter (no refetch needed).
  const displayed = useMemo(() => {
    if (!filters.orientation) return images;
    return images.filter(img => img.orientation === filters.orientation);
  }, [images, filters.orientation]);

  // Infinite scroll: auto-load a few pages, then stop so the footer is reachable.
  const AUTO_LOAD_LIMIT = 4;
  const sentinelRef = useRef(null);
  useEffect(() => {
    const el = sentinelRef.current;
    if (!el || page >= AUTO_LOAD_LIMIT) return; // stop auto-loading past the limit
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && hasMore && !isFetching) {
        setPage(p => p + 1);
      }
    }, { rootMargin: '300px' });
    observer.observe(el);
    return () => observer.disconnect();
  }, [hasMore, isFetching, page]);

  return (
    <main className="gallery-container">
      <div className="gallery-header">
        <h2 id="galleryTitle">{initialQuery ? `Discovering "${initialQuery}"` : 'Fresh Discoveries'}</h2>
      </div>

      <FilterBar filters={filters} setFilters={setFilters} />

      {displayed.length === 0 && !isFetching && (
        <div style={{ textAlign: 'center', width: '100%', color: 'var(--text-muted)', padding: '60px' }}>
          {filters.orientation && images.length > 0
            ? `No ${filters.orientation.toLowerCase()} images on this page. Try loading more or clearing the orientation filter.`
            : `No results found for "${effectiveQuery}". Try a broader term.`}
        </div>
      )}

      <div className="image-grid">
        {displayed.map(photo => (
          <ImageCard
            key={photo.id}
            photo={photo}
            onClick={setSelectedPhoto}
          />
        ))}
      </div>

      {isFetching && (
        <div className="loader">
          <div className="spinner"></div>
          <p>Curating visuals...</p>
        </div>
      )}

      {!isFetching && hasMore && images.length > 0 && (
        <div className="load-more-container" style={{ display: 'flex', justifyContent: 'center', marginTop: '40px' }}>
          <button className="btn-outline" onClick={() => setPage(p => p + 1)}>
            Load More Inspiration
          </button>
        </div>
      )}

      {/* Infinite-scroll sentinel */}
      <div ref={sentinelRef} style={{ height: 1 }} aria-hidden="true" />

      {selectedPhoto && (
        <ImageModal photo={selectedPhoto} onClose={() => setSelectedPhoto(null)} />
      )}
    </main>
  );
}
