import React, { useState } from 'react';
import { MagnifyingGlass } from '@phosphor-icons/react';
import { motion } from 'framer-motion';

export default function Hero({ onSearch }) {
  const [query, setQuery] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query.trim());
    }
  };

  const handleTagClick = (tag) => {
    setQuery(tag);
    onSearch(tag);
  };

  return (
    <header className="hero premium-hero">
      {/* Dynamic Background Element */}
      <div className="hero-bg-overlay"></div>
      
      <motion.div 
        className="hero-content"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <motion.div 
          className="badge"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <span className="badge-dot pulse-dot"></span>
          <span>Unrestricted Premium Media</span>
        </motion.div>
        
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
        >
          The creative universe of <br/><span className="text-gradient glass-text">free visuals.</span>
        </motion.h1>
        
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
        >
          Curated high-resolution photography for your next masterpiece. Completely copyright-free.
        </motion.p>
        
        <motion.form 
          className="search-form" 
          onSubmit={handleSubmit}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
        >
          <div className="search-input-wrapper premium-search">
            <MagnifyingGlass className="search-icon" />
            <input 
              type="text" 
              placeholder="Search 'neon city', 'minimalism'..." 
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              autoComplete="off" 
            />
            <button type="submit" className="search-btn premium-btn">Discover</button>
          </div>
        </motion.form>
        
        <motion.div 
          className="trending-searches"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.8 }}
        >
          {['Cyberpunk', 'Architecture', 'Moody Nature', 'Abstract', 'Neon'].map((tag, i) => (
            <motion.button 
              key={tag} 
              className="trend-tag premium-tag" 
              onClick={() => handleTagClick(tag)}
              whileHover={{ scale: 1.05, backgroundColor: 'rgba(255,255,255,0.15)' }}
              whileTap={{ scale: 0.95 }}
            >
              {tag}
            </motion.button>
          ))}
        </motion.div>
      </motion.div>
    </header>
  );
}
