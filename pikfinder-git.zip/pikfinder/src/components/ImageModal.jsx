import React, { useContext } from 'react';
import { X, Heart } from '@phosphor-icons/react';
import { AppContext } from '../context/AppContext';
import ColorPalette from './ColorPalette';
import FontPairing from './FontPairing';
import DownloadOptions from './DownloadOptions';

export default function ImageModal({ photo, onClose }) {
  const { isFavorite, toggleFavorite } = useContext(AppContext);
  if (!photo) return null;

  return (
    <div className="modal-overlay active" onClick={onClose}>
      <div className="modal-content image-modal-content" onClick={e => e.stopPropagation()}>
        <button className="close-modal" onClick={onClose}><X /></button>
        <div className="modal-image-container">
          <img src={photo.urls.full} alt={photo.alt_description} />
        </div>
        <div className="modal-info">
          <div className="photographer">
            <img src={photo.user.profile_image.medium} alt={photo.user.name} />
            <div>
              <h4>{photo.user.name}</h4>
              <span className="source-badge">Wikimedia Commons</span>
            </div>
          </div>

          <div className="modal-actions">
            <button
              className={`icon-btn-large ${isFavorite(photo.id) ? 'active' : ''}`}
              onClick={() => toggleFavorite(photo)}
              title="Add to Favorites"
            >
              <Heart weight={isFavorite(photo.id) ? 'fill' : 'regular'} />
            </button>
            <DownloadOptions photo={photo} />
          </div>

          <ColorPalette src={photo.urls.regular} />
          <FontPairing />
        </div>
      </div>
    </div>
  );
}
