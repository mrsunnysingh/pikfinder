import React, { useContext } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { Heart } from '@phosphor-icons/react';
import Logo from './Logo';
import { AppContext } from '../context/AppContext';
import ThemeToggle from './ThemeToggle';

export default function Navbar() {
  const { isLoggedIn, user, toggleAuthModal, logoutUser, favorites } = useContext(AppContext);
  const navigate = useNavigate();

  return (
    <nav className="navbar">
      <Link to="/" className="logo">
        <Logo size={30} />
      </Link>
      
      <div className="nav-links">
        <NavLink to="/" className={({ isActive }) => (isActive ? 'active' : '')} end>Discover</NavLink>
        <NavLink to="/collections" className={({ isActive }) => (isActive ? 'active' : '')}>Collections</NavLink>
        <NavLink to="/tools" className={({ isActive }) => (isActive ? 'active' : '')}>Free Tools</NavLink>
        
        <ThemeToggle />
        {!isLoggedIn ? (
          <div className="auth-buttons">
            <button className="btn-text" onClick={() => toggleAuthModal('login')}>Log In</button>
            <button className="btn-primary" onClick={() => toggleAuthModal('signup')}>Sign Up</button>
          </div>
        ) : (
          <div className="user-profile">
            <button
              className="btn-icon favorites-nav-btn"
              title="My Favorites"
              onClick={() => navigate('/favorites')}
              style={{ position: 'relative' }}
            >
              <Heart weight="fill" />
              {favorites.length > 0 && (
                <span className="fav-count-badge">{favorites.length}</span>
              )}
            </button>
            <div className="avatar-circle" title="Logout" onClick={logoutUser} style={{ cursor: 'pointer' }}>
              {user?.photoURL ? <img src={user.photoURL} alt="" /> : (user?.name ? user.name.charAt(0).toUpperCase() : 'U')}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
