import React, { useContext } from 'react';
import { Sun, Moon } from '@phosphor-icons/react';
import { AppContext } from '../context/AppContext';

export default function ThemeToggle({ className = '' }) {
  const { theme, toggleTheme } = useContext(AppContext);
  const isDark = theme === 'dark';
  return (
    <button
      className={`theme-toggle ${className}`}
      onClick={toggleTheme}
      title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
      aria-label="Toggle theme"
    >
      {isDark ? <Sun weight="fill" /> : <Moon weight="fill" />}
    </button>
  );
}
