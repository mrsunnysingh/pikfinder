import React, { useContext, useState, useRef, useEffect } from 'react';
import { AppContext } from '../../context/AppContext';
import ProfileDropdown from './ProfileDropdown';
import ThemeToggle from '../ThemeToggle';

export default function DashboardHeader() {
  const { user } = useContext(AppContext);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [dropdownRef]);

  return (
    <header className="dashboard-header">
      <div className="header-left">
        {/* Can put a breadcrumb or title here if needed */}
      </div>
      <div className="header-right">
        <ThemeToggle />
        <div className="profile-menu-container" ref={dropdownRef}>
          <div 
            className="avatar-circle" 
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            style={{ cursor: 'pointer' }}
          >
            {user?.photoURL ? <img src={user.photoURL} alt="" /> : (user?.name ? user.name.charAt(0).toUpperCase() : 'U')}
          </div>
          
          {isDropdownOpen && <ProfileDropdown onClose={() => setIsDropdownOpen(false)} />}
        </div>
      </div>
    </header>
  );
}
