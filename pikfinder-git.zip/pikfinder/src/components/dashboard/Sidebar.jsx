import React from 'react';
import { NavLink } from 'react-router-dom';
import Logo from '../Logo';
import {
  House, MagnifyingGlass, SquaresFour, Heart,
  EnvelopeSimple, PaintBrush, CircleHalf, Code, GridFour, InstagramLogo, TwitterLogo, GithubLogo
} from '@phosphor-icons/react';

const SOCIALS = {
  instagram: 'https://instagram.com/pikfinder',
  twitter: 'https://twitter.com/pikfinder',
  github: 'https://github.com/mrsunnysingh/pikfinder',
};

export default function Sidebar() {
  const linkClass = ({ isActive }) => (isActive ? 'nav-item active' : 'nav-item');

  return (
    <aside className="dashboard-sidebar">
      <div className="sidebar-header">
        <NavLink to="/dashboard" className="logo">
          <Logo size={28} />
        </NavLink>
      </div>

      <div className="sidebar-scrollable">
        <nav className="sidebar-nav">
          <NavLink to="/dashboard" className={linkClass} end>
            <House weight="fill" /> Home
          </NavLink>
          <NavLink to="/search" className={linkClass}>
            <MagnifyingGlass /> Search
          </NavLink>
          <NavLink to="/collections" className={linkClass}>
            <SquaresFour /> Collections
          </NavLink>
          <NavLink to="/favorites" className={linkClass}>
            <Heart /> Favorites
          </NavLink>
          <NavLink to="/backgrounds" className={linkClass}>
            <PaintBrush /> Backgrounds
          </NavLink>
          <NavLink to="/duotone" className={linkClass}>
            <CircleHalf /> Duotone
          </NavLink>
          <NavLink to="/gradient" className={linkClass}>
            <GridFour /> Gradient
          </NavLink>
          <NavLink to="/json" className={linkClass}>
            <Code /> JSON Viewer
          </NavLink>
          <NavLink to="/tools" className={linkClass}>
            <GridFour /> Free Tools
          </NavLink>
          <NavLink to="/contact" className={linkClass}>
            <EnvelopeSimple /> Contact
          </NavLink>
        </nav>
      </div>

      <div className="sidebar-footer sidebar-socials">
        <a href={SOCIALS.instagram} target="_blank" rel="noopener noreferrer" className="icon-btn-small" title="Instagram"><InstagramLogo /></a>
        <a href={SOCIALS.twitter} target="_blank" rel="noopener noreferrer" className="icon-btn-small" title="Twitter"><TwitterLogo /></a>
        <a href={SOCIALS.github} target="_blank" rel="noopener noreferrer" className="icon-btn-small" title="GitHub"><GithubLogo /></a>
      </div>
    </aside>
  );
}
