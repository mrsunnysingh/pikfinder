import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Config is read from environment variables (.env file at project root).
// Get these values from Firebase Console → Project settings → Your apps → Web app,
// or by running:  firebase apps:sdkconfig web --project 423715564608
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID,
};

// Fail loudly (and clearly) if the .env values are missing, so misconfig is obvious.
if (!firebaseConfig.apiKey || !firebaseConfig.projectId) {
  console.error(
    "[Firebase] Missing configuration. Create a .env file at the project root with your " +
    "VITE_FIREBASE_* values, then restart the dev server (npm run dev). " +
    "See .env.example for the required keys."
  );
}

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();
