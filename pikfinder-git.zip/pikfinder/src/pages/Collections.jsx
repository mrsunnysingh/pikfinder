import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight } from '@phosphor-icons/react';

const container = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.07 } },
};
const card = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' } },
};

const COLLECTIONS = [
  { title: 'SaaS Hero Images', query: 'saas startup dashboard', img: 'https://images.unsplash.com/photo-1551434678-e076c223a692?q=80&w=800&auto=format&fit=crop', span: 'wide' },
  { title: 'Startup Team Photos', query: 'business team office', img: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=800&auto=format&fit=crop' },
  { title: 'Modern Office', query: 'modern office interior', img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=800&auto=format&fit=crop' },
  { title: 'Healthcare', query: 'healthcare medical', img: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=800&auto=format&fit=crop' },
  { title: 'Product Mockups', query: 'product mockup device', img: 'https://images.unsplash.com/photo-1512499617640-c74ae3a79d37?q=80&w=800&auto=format&fit=crop', span: 'wide' },
  { title: 'Construction Assets', query: 'construction site building', img: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?q=80&w=800&auto=format&fit=crop' },
  { title: 'Travel Marketing', query: 'travel destination landscape', img: 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?q=80&w=800&auto=format&fit=crop' },
  { title: 'Education', query: 'education classroom learning', img: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=800&auto=format&fit=crop' },
  { title: 'Abstract Textures', query: 'abstract gradient background', img: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=800&auto=format&fit=crop' },
];

export default function Collections() {
  const navigate = useNavigate();
  const open = (query) => navigate(`/search?q=${encodeURIComponent(query)}`);

  return (
    <>
      <header className="page-header">
        <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          Curated Collections
        </motion.h1>
        <p>Hand-picked, ready-to-use asset sets for every kind of project.</p>
      </header>

      <motion.div className="collections-grid" variants={container} initial="hidden" animate="visible">
        {COLLECTIONS.map((c) => (
          <motion.button
            key={c.title}
            className={`collection-card ${c.span === 'wide' ? 'span-wide' : ''}`}
            variants={card}
            whileHover={{ y: -6 }}
            onClick={() => open(c.query)}
            style={{ backgroundImage: `url(${c.img})` }}
          >
            <div className="collection-overlay" />
            <div className="collection-content">
              <h3>{c.title}</h3>
              <span className="collection-cta">Explore <ArrowRight weight="bold" /></span>
            </div>
          </motion.button>
        ))}
      </motion.div>
    </>
  );
}
