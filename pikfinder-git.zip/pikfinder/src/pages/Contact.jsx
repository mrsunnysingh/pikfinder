import React, { useState } from 'react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { Bug, Star, Lightbulb, Sparkle, ChatCircle } from '@phosphor-icons/react';
import { useToast } from '../components/Toast';

const CATEGORIES = [
  { value: 'Bug', label: 'Bug report', icon: Bug },
  { value: 'Review', label: 'Review', icon: Star },
  { value: 'Suggestion', label: 'Suggestion', icon: Lightbulb },
  { value: 'Feature Request', label: 'Feature request', icon: Sparkle },
  { value: 'General', label: 'General', icon: ChatCircle },
];

// Optional Google Apps Script endpoint (emails you + appends to a Google Sheet).
// Set VITE_CONTACT_ENDPOINT in .env — see google-apps-script/Code.gs for setup.
const CONTACT_ENDPOINT = import.meta.env.VITE_CONTACT_ENDPOINT;

export default function Contact() {
  const toast = useToast();
  const [status, setStatus] = useState(null); // null | 'ok' | 'error'
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', category: 'Bug', message: '' });

  const update = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setStatus(null);

    const payload = {
      name: form.name,
      email: form.email,
      category: form.category,
      message: form.message,
    };

    let delivered = false;

    // 1) Send to Google Apps Script (email + spreadsheet), if configured.
    if (CONTACT_ENDPOINT) {
      try {
        await fetch(CONTACT_ENDPOINT, {
          method: 'POST',
          mode: 'no-cors', // Apps Script doesn't return CORS headers; fire-and-forget.
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify(payload),
        });
        delivered = true;
      } catch (err) {
        console.warn('Contact endpoint failed:', err?.message || err);
      }
    }

    // 2) Always keep a record in Firestore (reliable, verifiable).
    try {
      await addDoc(collection(db, 'contact_messages'), { ...payload, timestamp: serverTimestamp() });
      delivered = true;
    } catch (err) {
      console.error('Firestore write failed:', err?.message || err);
    }

    setLoading(false);
    if (delivered) {
      setStatus('ok');
      toast('Message sent — we\'ll reply soon');
      setForm({ name: '', email: '', category: 'Bug', message: '' });
    } else {
      setStatus('error');
      toast('Could not send message', 'error');
    }
  };

  return (
    <>
      <header className="page-header">
        <h1>Contact Us</h1>
        <p>Report a bug, leave a review, or suggest a feature — we read everything.</p>
      </header>

      <div className="contact-wrapper">
        <form className="contact-form" onSubmit={handleSubmit}>
          <div className="contact-row">
            <div className="input-group">
              <label>Name</label>
              <input type="text" placeholder="Your name" required value={form.name} onChange={e => update('name', e.target.value)} />
            </div>
            <div className="input-group">
              <label>Email</label>
              <input type="email" placeholder="you@company.com" required value={form.email} onChange={e => update('email', e.target.value)} />
            </div>
          </div>

          <div className="input-group">
            <label>Category</label>
            <div className="category-select">
              {CATEGORIES.map(c => (
                <button
                  type="button"
                  key={c.value}
                  className={`category-option ${form.category === c.value ? 'active' : ''}`}
                  onClick={() => update('category', c.value)}
                >
                  <c.icon weight={form.category === c.value ? 'fill' : 'regular'} /> {c.label}
                </button>
              ))}
            </div>
          </div>

          <div className="input-group">
            <label>Message</label>
            <textarea placeholder="How can we help you today?" required value={form.message} onChange={e => update('message', e.target.value)} rows={5}></textarea>
          </div>

          <button type="submit" className="btn-primary w-100" disabled={loading}>
            {loading ? <div className="spinner" style={{ width: '20px', height: '20px', borderWidth: '2px', margin: 0 }}></div> : 'Send Message'}
          </button>

          {status === 'ok' && <p className="form-status ok">Thanks! Your {form.category ? '' : ''}message was sent. We'll get back to you within 24 hours.</p>}
          {status === 'error' && <p className="form-status error">Couldn't send right now. Please try again in a moment.</p>}
        </form>
      </div>
    </>
  );
}
