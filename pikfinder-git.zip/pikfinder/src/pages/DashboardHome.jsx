import React, { useContext, useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppContext } from '../context/AppContext';
import {
  MagnifyingGlass, Heart, FolderSimple, DownloadSimple, ClockCounterClockwise,
  ArrowRight, Buildings, Heartbeat, Hammer, GraduationCap, AirplaneTilt,
  Barbell, DeviceMobile, ShoppingBag, UsersThree, Sparkle, PaintBrush, Cube
} from '@phosphor-icons/react';

// Designer quick-categories from the product spec, mapped to smart search queries.
const CATEGORIES = [
  { label: 'Website Hero', q: 'landscape mountain', icon: Sparkle, color: '#8b5cf6' },
  { label: 'SaaS', q: 'laptop computer', icon: DeviceMobile, color: '#3b82f6' },
  { label: 'Healthcare', q: 'hospital medicine', icon: Heartbeat, color: '#10b981' },
  { label: 'Construction', q: 'construction building', icon: Hammer, color: '#f59e0b' },
  { label: 'Real Estate', q: 'house architecture', icon: Buildings, color: '#06b6d4' },
  { label: 'Education', q: 'school classroom', icon: GraduationCap, color: '#ec4899' },
  { label: 'Travel', q: 'travel landscape', icon: AirplaneTilt, color: '#0ea5e9' },
  { label: 'Fitness', q: 'fitness sport', icon: Barbell, color: '#ef4444' },
  { label: 'Business Teams', q: 'business people', icon: UsersThree, color: '#a855f7' },
  { label: 'E-Commerce', q: 'shopping market', icon: ShoppingBag, color: '#14b8a6' },
  { label: 'Product Mockups', q: 'smartphone device', icon: Cube, color: '#f97316' },
  { label: 'Abstract BG', q: 'abstract pattern', icon: PaintBrush, color: '#f43f5e' },
];

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

export default function DashboardHome() {
  const { user, favorites, searchHistory, downloadHistory } = useContext(AppContext);
  const navigate = useNavigate();
  const [term, setTerm] = useState('');

  const firstName = useMemo(() => (user?.name || 'there').split(' ')[0], [user]);

  const goSearch = (q) => {
    const query = (q ?? term).trim();
    if (!query) return;
    navigate(`/search?q=${encodeURIComponent(query)}`);
  };

  const stats = [
    { label: 'Saved images', value: favorites.length, icon: Heart, color: '#f43f5e', onClick: () => navigate('/favorites') },
    { label: 'Collections', value: 7, icon: FolderSimple, color: '#8b5cf6', onClick: () => navigate('/collections') },
    { label: 'Downloads', value: downloadHistory.length, icon: DownloadSimple, color: '#3b82f6', onClick: () => navigate('/search') },
    { label: 'Searches', value: searchHistory.length, icon: ClockCounterClockwise, color: '#10b981', onClick: () => navigate('/search') },
  ];

  const recentFavorites = favorites.slice(-6).reverse();

  return (
    <div className="dashboard-home">
      {/* Greeting + search */}
      <div className="dashboard-hero">
        <h1>{greeting()}, {firstName} 👋</h1>
        <p className="dashboard-subtitle">What are you designing today? Search millions of free, commercial-use assets.</p>
        <form
          className="dashboard-search"
          onSubmit={(e) => { e.preventDefault(); goSearch(); }}
        >
          <MagnifyingGlass />
          <input
            type="text"
            value={term}
            onChange={(e) => setTerm(e.target.value)}
            placeholder='Try "hero image for a healthcare website"'
          />
          <button type="submit" className="btn-primary" style={{ padding: '8px 20px' }}>Search</button>
        </form>
      </div>

      {/* Live stats */}
      <div className="stats-row">
        {stats.map((s) => (
          <button key={s.label} className="stat-card" onClick={s.onClick}>
            <div className="stat-icon" style={{ color: s.color, background: `${s.color}1a` }}>
              <s.icon weight="fill" />
            </div>
            <div className="stat-text">
              <span className="stat-value">{s.value}</span>
              <span className="stat-label">{s.label}</span>
            </div>
          </button>
        ))}
      </div>

      {/* Designer categories */}
      <div className="dashboard-section-block">
        <div className="section-header">
          <h3>Designer categories</h3>
        </div>
        <div className="category-grid">
          {CATEGORIES.map((c) => (
            <button key={c.label} className="category-chip" onClick={() => goSearch(c.q)}>
              <span className="category-chip-icon" style={{ color: c.color, background: `${c.color}1a` }}>
                <c.icon weight="fill" />
              </span>
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Recent favorites */}
      <div className="dashboard-section-block">
        <div className="section-header">
          <h3>Recently saved</h3>
          {favorites.length > 0 && (
            <button className="btn-text-accent" onClick={() => navigate('/favorites')}>
              View all <ArrowRight />
            </button>
          )}
        </div>

        {recentFavorites.length > 0 ? (
          <div className="recent-grid">
            {recentFavorites.map((p) => (
              <div key={p.id} className="recent-card" onClick={() => navigate('/favorites')}>
                <img src={p.urls?.regular || p.urls?.full} alt={p.alt_description || 'Saved image'} loading="lazy" />
                <div className="recent-overlay"><Heart weight="fill" /></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <Heart size={40} />
            <p>You haven't saved anything yet.</p>
            <button className="btn-primary" onClick={() => navigate('/search')}>Start exploring</button>
          </div>
        )}
      </div>

      {/* Recent searches */}
      <div className="dashboard-section-block">
        <div className="section-header"><h3>Recent searches</h3></div>
        {searchHistory.length > 0 ? (
          <div className="history-chips">
            {searchHistory.slice(0, 12).map((term, i) => (
              <button key={`${term}-${i}`} className="history-chip" onClick={() => navigate(`/search?q=${encodeURIComponent(term)}`)}>
                <ClockCounterClockwise /> {term}
              </button>
            ))}
          </div>
        ) : (
          <p className="history-empty">Your searches will show up here once you start searching.</p>
        )}
      </div>

      {/* Recent downloads */}
      <div className="dashboard-section-block">
        <div className="section-header"><h3>Recent downloads</h3></div>
        {downloadHistory.length > 0 ? (
          <div className="recent-grid">
            {downloadHistory.slice(0, 6).map((d) => (
              <div key={d.id} className="recent-card" onClick={() => navigate('/search')}>
                <img src={d.url} alt={d.alt || 'Downloaded image'} loading="lazy" />
                <div className="recent-overlay"><DownloadSimple weight="fill" /></div>
              </div>
            ))}
          </div>
        ) : (
          <p className="history-empty">Images you download will appear here.</p>
        )}
      </div>
    </div>
  );
}
