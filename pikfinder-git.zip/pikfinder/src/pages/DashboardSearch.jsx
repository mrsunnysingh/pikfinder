import React, { useEffect, useContext } from 'react';
import { useSearchParams } from 'react-router-dom';
import { MagnifyingGlass, TrendUp } from '@phosphor-icons/react';
import Gallery from '../components/Gallery';
import { AppContext } from '../context/AppContext';

const TRENDING = ['Minimal', 'Nature', 'Neon', 'Architecture', 'Ocean', 'Space', 'Vintage', 'Gradient'];
const CATEGORIES = [
  { label: 'Nature', q: 'nature landscape', emoji: '🌿', color: '#10b981' },
  { label: 'Technology', q: 'technology computer', emoji: '💻', color: '#3b82f6' },
  { label: 'Business', q: 'business office', emoji: '💼', color: '#a855f7' },
  { label: 'Travel', q: 'travel landscape', emoji: '✈️', color: '#0ea5e9' },
  { label: 'Food', q: 'food cuisine', emoji: '🍽️', color: '#f59e0b' },
  { label: 'Abstract', q: 'abstract pattern', emoji: '🎨', color: '#ec4899' },
  { label: 'Animals', q: 'animals wildlife', emoji: '🦊', color: '#ef4444' },
  { label: 'Architecture', q: 'architecture building', emoji: '🏛️', color: '#06b6d4' },
];

export default function DashboardSearch() {
  const [searchParams, setSearchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const { logSearch } = useContext(AppContext);

  useEffect(() => {
    if (query) logSearch(query);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  const submit = (e) => {
    e.preventDefault();
    const q = e.target.elements.q.value.trim();
    if (q) setSearchParams({ q });
  };
  const run = (q) => setSearchParams({ q });

  return (
    <div className="dashboard-search-page">
      <form className="dashboard-search" onSubmit={submit} style={{ maxWidth: '700px', marginBottom: '28px' }} key={query}>
        <MagnifyingGlass />
        <input name="q" type="text" defaultValue={query} placeholder="Search millions of free design assets…" autoFocus />
        <button type="submit" className="btn-primary" style={{ padding: '8px 20px' }}>Search</button>
      </form>

      {query ? (
        <Gallery initialQuery={query} />
      ) : (
        <div className="search-explore">
          <div className="explore-block">
            <div className="explore-head"><TrendUp weight="fill" /> Trending searches</div>
            <div className="search-suggestions">
              {TRENDING.map(t => (
                <button key={t} className="history-chip" onClick={() => run(t.toLowerCase())}>{t}</button>
              ))}
            </div>
          </div>

          <div className="explore-block">
            <div className="explore-head">Browse by category</div>
            <div className="explore-grid">
              {CATEGORIES.map(c => (
                <button key={c.label} className="explore-tile" onClick={() => run(c.q)} style={{ '--tile': c.color }}>
                  <span className="explore-emoji" style={{ background: `${c.color}1a` }}>{c.emoji}</span>
                  <span>{c.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
