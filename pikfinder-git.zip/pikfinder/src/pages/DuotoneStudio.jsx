import React, { useRef, useState, useEffect, useCallback } from 'react';
import { UploadSimple, DownloadSimple, LinkSimple } from '@phosphor-icons/react';
import { useToast } from '../components/Toast';

const PRESETS = [
  { name: 'Violet Pink', shadow: '#2e1065', highlight: '#f9a8d4' },
  { name: 'Ocean', shadow: '#0c4a6e', highlight: '#67e8f9' },
  { name: 'Sunset', shadow: '#7c2d12', highlight: '#fde68a' },
  { name: 'Emerald', shadow: '#064e3b', highlight: '#6ee7b7' },
  { name: 'Grape', shadow: '#1e1b4b', highlight: '#c4b5fd' },
  { name: 'Noir', shadow: '#0a0a0a', highlight: '#ffffff' },
];

const SAMPLE = 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/68/Joe_Cocker_-_Grosse_Freiheit_36_-_Hamburg.jpg/640px-Joe_Cocker_-_Grosse_Freiheit_36_-_Hamburg.jpg';

const hexToRgb = (hex) => {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};

export default function DuotoneStudio() {
  const toast = useToast();
  const canvasRef = useRef(null);
  const imgRef = useRef(null);
  const loadTokenRef = useRef(0);
  const [shadow, setShadow] = useState(PRESETS[0].shadow);
  const [highlight, setHighlight] = useState(PRESETS[0].highlight);
  const [url, setUrl] = useState('');
  const [ready, setReady] = useState(false);
  const [error, setError] = useState(null);

  const applyDuotone = useCallback(() => {
    const canvas = canvasRef.current;
    const img = imgRef.current;
    if (!canvas || !img || !img.complete || !img.naturalWidth) return;

    const maxW = 900;
    const scale = Math.min(1, maxW / img.naturalWidth);
    canvas.width = Math.round(img.naturalWidth * scale);
    canvas.height = Math.round(img.naturalHeight * scale);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    let data;
    try {
      data = ctx.getImageData(0, 0, canvas.width, canvas.height);
    } catch {
      setError('This image is protected and can\'t be edited. Try uploading a file instead.');
      return;
    }
    setError(null);

    const [sr, sg, sb] = hexToRgb(shadow);
    const [hr, hg, hb] = hexToRgb(highlight);
    const px = data.data;
    for (let i = 0; i < px.length; i += 4) {
      const l = (0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2]) / 255;
      px[i] = sr + (hr - sr) * l;
      px[i + 1] = sg + (hg - sg) * l;
      px[i + 2] = sb + (hb - sb) * l;
    }
    ctx.putImageData(data, 0, 0);
    setReady(true);
  }, [shadow, highlight]);

  const loadImage = useCallback((src, crossOrigin = true) => {
    const token = ++loadTokenRef.current;
    setError(null);
    const img = new Image();
    if (crossOrigin) img.crossOrigin = 'anonymous';
    img.onload = () => {
      if (token !== loadTokenRef.current) return; // a newer load started
      imgRef.current = img;
      applyDuotone();
    };
    img.onerror = () => {
      if (token !== loadTokenRef.current) return; // ignore stale failures
      setError('Could not load that image.');
    };
    img.src = src;
  }, [applyDuotone]);

  useEffect(() => { loadImage(SAMPLE); }, [loadImage]);
  useEffect(() => { if (imgRef.current?.complete) applyDuotone(); }, [shadow, highlight, applyDuotone]);

  const onFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => loadImage(reader.result, false); // data URL — never tainted
    reader.readAsDataURL(file);
  };

  const applyPreset = (p) => { setShadow(p.shadow); setHighlight(p.highlight); };

  const exportPng = () => {
    const canvas = canvasRef.current;
    canvas.toBlob((blob) => {
      const u = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = u; a.download = 'pikfinder-duotone.png';
      document.body.appendChild(a); a.click(); URL.revokeObjectURL(u); a.remove();
      toast('Exported PNG');
    }, 'image/png');
  };

  return (
    <div className="duotone-studio">
      <header className="page-header" style={{ padding: '40px 0 24px' }}>
        <h1>Duotone Studio</h1>
        <p>Turn any photo into a striking two-tone graphic. Upload an image, pick a duotone, export a PNG.</p>
      </header>

      <div className="duotone-canvas-wrap">
        <canvas ref={canvasRef} className="duotone-canvas" />
      </div>
      {error && <p className="form-status error" style={{ textAlign: 'center' }}>{error}</p>}

      <div className="duotone-presets">
        {PRESETS.map(p => (
          <button
            key={p.name}
            className={`duotone-preset ${shadow === p.shadow && highlight === p.highlight ? 'active' : ''}`}
            onClick={() => applyPreset(p)}
            title={p.name}
          >
            <span className="duotone-swatch" style={{ background: `linear-gradient(135deg, ${p.shadow}, ${p.highlight})` }} />
            {p.name}
          </button>
        ))}
      </div>

      <div className="duotone-controls">
        <label className="duotone-color">Shadow <input type="color" value={shadow} onChange={e => setShadow(e.target.value)} /></label>
        <label className="duotone-color">Highlight <input type="color" value={highlight} onChange={e => setHighlight(e.target.value)} /></label>

        <label className="btn-outline duotone-upload">
          <UploadSimple /> Upload image
          <input type="file" accept="image/*" onChange={onFile} hidden />
        </label>

        <div className="duotone-url">
          <LinkSimple />
          <input type="url" placeholder="…or paste an image URL" value={url} onChange={e => setUrl(e.target.value)} />
          <button className="btn-outline" onClick={() => url && loadImage(url)}>Load</button>
        </div>

        <button className="btn-primary" onClick={exportPng} disabled={!ready}>
          <DownloadSimple /> Export PNG
        </button>
      </div>
    </div>
  );
}
