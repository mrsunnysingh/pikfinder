import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { PaintBrush, CircleHalf, Code, Palette, ArrowRight, MagnifyingGlass } from '@phosphor-icons/react';

const TOOLS = [
  { title: 'Background Generator', desc: 'Gradients, mesh & abstract backgrounds. Export PNG.', icon: PaintBrush, color: '#8b5cf6', to: '/backgrounds' },
  { title: 'Gradient Generator', desc: 'Design gradients and export as CSS or SVG.', icon: Code, color: '#3b82f6', to: '/gradient' },
  { title: 'Duotone Studio', desc: 'Turn any photo into a two-tone graphic.', icon: CircleHalf, color: '#ec4899', to: '/duotone' },
  { title: 'JSON Viewer', desc: 'Format & explore JSON in a collapsible tree.', icon: Code, color: '#10b981', to: '/json' },
  { title: 'Image Search', desc: 'Search millions of free, copyright-free images.', icon: MagnifyingGlass, color: '#f59e0b', to: '/search' },
  { title: 'Color & Fonts', desc: 'Extract palettes and get font pairings from any image.', icon: Palette, color: '#f43f5e', to: '/search' },
];

export default function FreeTools() {
  const navigate = useNavigate();
  return (
    <>
      <header className="page-header">
        <h1>Free Tools</h1>
        <p>A growing toolkit for designers, marketers, and creators — all free, no sign-up required.</p>
      </header>

      <div className="tools-grid">
        {TOOLS.map((t, i) => (
          <motion.button
            key={t.title}
            className="tool-hub-card"
            onClick={() => navigate(t.to)}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            whileHover={{ y: -5 }}
          >
            <span className="tool-hub-icon" style={{ color: t.color, background: `${t.color}1a` }}>
              <t.icon weight="fill" />
            </span>
            <h3>{t.title}</h3>
            <p>{t.desc}</p>
            <span className="tool-hub-cta">Open <ArrowRight weight="bold" /></span>
          </motion.button>
        ))}
      </div>
    </>
  );
}
