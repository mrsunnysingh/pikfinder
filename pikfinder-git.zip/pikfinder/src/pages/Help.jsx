import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { CaretDown, Question, EnvelopeSimple, MagnifyingGlass } from '@phosphor-icons/react';

const FAQS = [
  { q: 'Is Pik Finder really free?', a: 'Yes. All images and tools are free to use, including for commercial projects. Tips via the support page are appreciated but never required.' },
  { q: 'Do I need an account?', a: 'No — you can search, download, and use every tool without an account. Signing up just lets you save favorites, collections, and history across devices.' },
  { q: 'Why do I have to verify my email?', a: 'Email verification keeps accounts secure and prevents spam. After signing up, check your inbox for a verification link, then log in.' },
  { q: 'Can I use these images commercially?', a: 'Most images are public domain or CC0 and can be used commercially without attribution. Some carry other licenses — always check the image\'s source page. See our License Details for specifics.' },
  { q: 'How do the design tools work?', a: 'Everything runs in your browser: extract color palettes and font pairings from any image, generate gradients (with CSS/SVG export), create backgrounds, and apply duotone effects. Nothing is uploaded to a server.' },
  { q: 'How do I change my avatar or name?', a: 'Open Settings from your profile menu. You can pick a generated avatar, paste an image URL, upload a file, or reset to your initials.' },
  { q: 'How do I delete my account?', a: 'Go to Settings → Danger zone → Delete account. This permanently removes your account and data. If prompted, log out and back in first for security.' },
  { q: 'The image search returned nothing — why?', a: 'Very specific phrases can return few results from our public source. Try a broader keyword; the search also auto-broadens when a term has no matches.' },
];

function FaqItem({ q, a }) {
  const [open, setOpen] = useState(false);
  return (
    <div className={`faq-item ${open ? 'open' : ''}`}>
      <button className="faq-q" onClick={() => setOpen(o => !o)}>
        {q} <CaretDown className="faq-caret" />
      </button>
      {open && <div className="faq-a">{a}</div>}
    </div>
  );
}

export default function Help() {
  return (
    <>
      <header className="page-header" style={{ paddingBottom: '32px' }}>
        <h1>Help Center</h1>
        <p>Answers to common questions. Can't find what you need? We're one message away.</p>
      </header>

      <div className="help-container">
        <div className="help-cards">
          <Link to="/tools" className="help-card"><MagnifyingGlass /><span>Explore tools</span></Link>
          <Link to="/contact" className="help-card"><EnvelopeSimple /><span>Contact us</span></Link>
          <Link to="/license" className="help-card"><Question /><span>License info</span></Link>
        </div>

        <h2 className="help-heading">Frequently asked questions</h2>
        <div className="faq-list">
          {FAQS.map((f, i) => <FaqItem key={i} {...f} />)}
        </div>

        <div className="help-cta">
          <p>Still stuck?</p>
          <Link to="/contact" className="btn-primary">Contact support</Link>
        </div>
      </div>
    </>
  );
}
