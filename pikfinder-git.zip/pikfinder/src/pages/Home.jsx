import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import Hero from '../components/Hero';
import Gallery from '../components/Gallery';

export default function Home() {
  const [searchParams] = useSearchParams();
  const queryFromUrl = searchParams.get('q');
  const [searchQuery, setSearchQuery] = useState(queryFromUrl || 'neon dark');

  // Update search when URL query parameter changes (e.g. from Collections page)
  useEffect(() => {
    if (queryFromUrl) {
      setSearchQuery(queryFromUrl);
    }
  }, [queryFromUrl]);

  return (
    <>
      <Hero onSearch={setSearchQuery} />
      <Gallery initialQuery={searchQuery} />
    </>
  );
}
