import React, { useState } from 'react';
import { CaretRight, CaretDown, Copy, Check, TreeStructure, Minus } from '@phosphor-icons/react';
import { useToast } from '../components/Toast';

const SAMPLE = `{
  "name": "Pik Finder",
  "free": true,
  "tools": ["search", "duotone", "gradient"],
  "stats": { "users": 1200, "downloads": 48210 },
  "owner": { "handle": "@pikfinder", "since": 2026 }
}`;

function JsonNode({ keyName, value, depth = 0, last = true }) {
  const [open, setOpen] = useState(depth < 2);
  const isObject = value && typeof value === 'object';
  const isArray = Array.isArray(value);

  if (!isObject) {
    let cls = 'jv-num';
    if (typeof value === 'string') cls = 'jv-str';
    else if (typeof value === 'boolean') cls = 'jv-bool';
    else if (value === null) cls = 'jv-null';
    const display = typeof value === 'string' ? `"${value}"` : String(value);
    return (
      <div className="jv-row" style={{ paddingLeft: depth * 16 }}>
        {keyName !== undefined && <span className="jv-key">"{keyName}"</span>}
        {keyName !== undefined && <span className="jv-colon">: </span>}
        <span className={cls}>{display}</span>{!last && <span className="jv-comma">,</span>}
      </div>
    );
  }

  const entries = isArray ? value.map((v, i) => [i, v]) : Object.entries(value);
  const open_b = isArray ? '[' : '{';
  const close_b = isArray ? ']' : '}';

  return (
    <div className="jv-node">
      <div className="jv-row jv-clickable" style={{ paddingLeft: depth * 16 }} onClick={() => setOpen(o => !o)}>
        <span className="jv-caret">{open ? <CaretDown /> : <CaretRight />}</span>
        {keyName !== undefined && <span className="jv-key">"{keyName}"</span>}
        {keyName !== undefined && <span className="jv-colon">: </span>}
        <span className="jv-brace">{open_b}</span>
        {!open && <span className="jv-preview"> {entries.length} {entries.length === 1 ? 'item' : 'items'} </span>}
        {!open && <span className="jv-brace">{close_b}</span>}
        {!open && !last && <span className="jv-comma">,</span>}
      </div>
      {open && (
        <>
          {entries.map(([k, v], i) => (
            <JsonNode key={k} keyName={k} value={v} depth={depth + 1} last={i === entries.length - 1} />
          ))}
          <div className="jv-row" style={{ paddingLeft: depth * 16 }}>
            <span className="jv-brace">{close_b}</span>{!last && <span className="jv-comma">,</span>}
          </div>
        </>
      )}
    </div>
  );
}

export default function JsonViewer() {
  const toast = useToast();
  const [input, setInput] = useState(SAMPLE);
  const [parsed, setParsed] = useState(() => { try { return JSON.parse(SAMPLE); } catch { return null; } });
  const [error, setError] = useState(null);
  const [copied, setCopied] = useState(false);

  const parse = (text) => {
    try {
      setParsed(JSON.parse(text));
      setError(null);
    } catch (e) {
      setParsed(null);
      setError(e.message);
    }
  };

  const onChange = (e) => { setInput(e.target.value); parse(e.target.value); };

  const format = () => {
    if (parsed) { const f = JSON.stringify(parsed, null, 2); setInput(f); }
  };
  const minify = () => {
    if (parsed) { const m = JSON.stringify(parsed); setInput(m); }
  };
  const copyOut = async () => {
    if (!parsed) return;
    try {
      await navigator.clipboard.writeText(JSON.stringify(parsed, null, 2));
      setCopied(true); toast('Formatted JSON copied'); setTimeout(() => setCopied(false), 1400);
    } catch { /* blocked */ }
  };

  return (
    <div className="json-viewer">
      <header className="page-header" style={{ padding: '40px 0 24px' }}>
        <h1>JSON Viewer</h1>
        <p>Paste JSON to see it in a friendly, collapsible tree. Format, minify, and copy.</p>
      </header>

      <div className="jv-grid">
        <div className="jv-pane">
          <div className="jv-pane-head">
            <span>Input</span>
            <div className="jv-actions">
              <button className="code-copy-btn" onClick={format}><TreeStructure /> Format</button>
              <button className="code-copy-btn" onClick={minify}><Minus /> Minify</button>
            </div>
          </div>
          <textarea className="jv-input" value={input} onChange={onChange} spellCheck={false} placeholder="Paste your JSON here…" />
          {error && <p className="jv-error">Invalid JSON: {error}</p>}
        </div>

        <div className="jv-pane">
          <div className="jv-pane-head">
            <span>Tree</span>
            <button className="code-copy-btn" onClick={copyOut} disabled={!parsed}>{copied ? <><Check weight="bold" /> Copied</> : <><Copy /> Copy</>}</button>
          </div>
          <div className="jv-tree">
            {parsed !== null ? <JsonNode value={parsed} /> : <p className="jv-error">Nothing to show — fix the JSON on the left.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
