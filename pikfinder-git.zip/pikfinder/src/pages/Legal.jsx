import React from 'react';

export default function Legal() {
  return (
    <>
      <header className="page-header" style={{ paddingBottom: '40px' }}>
        <h1>Legal & Licensing</h1>
        <p>Transparency and freedom are at the core of PikFinder.</p>
      </header>
      
      <div className="legal-container">
        <h2>License Summary</h2>
        <p>All images on PikFinder are sourced from public domain databases, primarily Wikimedia Commons, and are provided under the <strong>Creative Commons Zero (CC0)</strong> license or similar unrestricted licenses.</p>
        
        <ul>
          <li><strong>What you can do:</strong> Download, copy, modify, distribute, and use the images for free, including for commercial purposes, without asking permission from or providing attribution to the photographer or PikFinder.</li>
          <li><strong>What you cannot do:</strong> You cannot imply endorsement of your product by the people or brands depicted in the images, nor can you sell the unaltered images as standalone products.</li>
        </ul>
        
        <h2>Terms of Service</h2>
        <p>By accessing PikFinder, you agree to our Terms of Service. We act as an aggregator of public domain media. We do not host these images directly, but proxy them for your convenience.</p>
        
        <h2>Privacy Policy</h2>
        <p>We respect your privacy. If you create an account to save favorites, your email and name are securely stored. We do not sell your data to third parties. If you wish to delete your account, please contact us.</p>
      </div>
    </>
  );
}
