import React from 'react';
import { Link } from 'react-router-dom';

export default function License() {
  return (
    <>
      <header className="page-header" style={{ paddingBottom: '32px' }}>
        <h1>License Details</h1>
        <p>What you can and can't do with images from Pik Finder.</p>
      </header>

      <div className="legal-container">
        <p className="legal-updated">Last updated: July 2026</p>

        <h2>Where images come from</h2>
        <p>Images surfaced by Pik Finder are aggregated from public repositories — primarily Wikimedia Commons. Most are in the public domain or released under open licenses such as Creative Commons Zero (CC0) or other Creative Commons licenses.</p>

        <h2>What you can do</h2>
        <ul>
          <li>Download, copy, edit, and use images for personal and commercial projects.</li>
          <li>Use them without payment.</li>
          <li>Use most of them without attribution — though crediting the creator is always appreciated.</li>
        </ul>

        <h2>What you should check</h2>
        <p>Not every image on Wikimedia Commons is CC0. Some carry licenses (for example, CC BY or CC BY-SA) that <strong>require attribution</strong> or <strong>share-alike</strong> terms. Before using an image commercially, open its source page and confirm its specific license. Pik Finder surfaces images for convenience but cannot guarantee the licensing status of any individual file.</p>

        <h2>What you cannot do</h2>
        <ul>
          <li>Imply endorsement by any person, brand, or organization depicted in an image.</li>
          <li>Resell unaltered images as standalone stock products.</li>
          <li>Use images in a way that is unlawful, defamatory, or infringing.</li>
        </ul>

        <h2>Recognizable people and trademarks</h2>
        <p>An open license covers copyright, not other rights. Images containing recognizable people, logos, or trademarks may require additional permissions (such as a model or property release) depending on how you use them.</p>

        <h2>No warranty</h2>
        <p>Images are provided "as is". Pik Finder makes no warranty regarding their licensing, fitness, or suitability for any purpose. You are responsible for your own use.</p>

        <div className="legal-nav">
          <Link to="/terms">Terms of Service</Link>
          <Link to="/privacy">Privacy Policy</Link>
        </div>
      </div>
    </>
  );
}
