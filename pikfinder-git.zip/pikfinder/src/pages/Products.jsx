import React, { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Crown,
  Lightning,
  Rocket,
  CheckCircle,
  Image,
  CloudArrowDown,
  Palette,
  ShieldCheck,
  ArrowRight,
  Star,
  Users,
  Sparkle,
} from '@phosphor-icons/react';
import { AppContext } from '../context/AppContext';

const plans = [
  {
    id: 'free',
    name: 'Explorer',
    price: '$0',
    period: 'forever',
    description: 'Perfect for hobbyists and personal projects.',
    icon: Lightning,
    gradient: 'linear-gradient(135deg, #334155, #1e293b)',
    accentColor: '#94a3b8',
    features: [
      'Browse unlimited images',
      'Standard resolution downloads',
      'Basic search filters',
      'Wikimedia Commons access',
      'Personal use license',
      'Community support',
    ],
    cta: 'Get Started Free',
    ctaAction: 'signup',
    popular: false,
  },
  {
    id: 'pro',
    name: 'Creator Pro',
    price: '$12',
    period: '/month',
    description: 'For professionals who demand premium quality.',
    icon: Crown,
    gradient: 'linear-gradient(135deg, #8b5cf6, #ec4899)',
    accentColor: '#a78bfa',
    features: [
      'Everything in Explorer',
      'Full resolution downloads',
      'Advanced AI search',
      'Curated collections access',
      'Commercial use license',
      'Priority support',
      'No watermarks',
      'Batch downloads (up to 50)',
    ],
    cta: 'Start 14-Day Trial',
    ctaAction: 'signup',
    popular: true,
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: '$49',
    period: '/month',
    description: 'For teams and agencies at scale.',
    icon: Rocket,
    gradient: 'linear-gradient(135deg, #f97316, #ef4444)',
    accentColor: '#fb923c',
    features: [
      'Everything in Creator Pro',
      'API access (10k req/day)',
      'Team collaboration tools',
      'Custom brand collections',
      'Extended commercial license',
      'Dedicated account manager',
      'SLA & uptime guarantee',
      'Unlimited batch downloads',
      'White-label integration',
    ],
    cta: 'Contact Sales',
    ctaAction: 'contact',
    popular: false,
  },
];

const features = [
  {
    icon: Image,
    title: 'Millions of Visuals',
    description:
      'Access an ever-growing library of high-resolution, copyright-free imagery sourced from global commons.',
    link: '/',
  },
  {
    icon: CloudArrowDown,
    title: 'Instant Downloads',
    description:
      'Download any image in full resolution with a single click. No sign-up walls, no friction.',
    link: '/',
  },
  {
    icon: Palette,
    title: 'AI-Powered Curation',
    description:
      'Our intelligent search understands aesthetics—not just keywords. Find the vibe, not just the subject.',
    link: '/collections',
  },
  {
    icon: ShieldCheck,
    title: '100% Copyright-Free',
    description:
      'Every image is verified for unrestricted use. Use commercially, modify freely, no attribution required.',
    link: '/legal',
  },
  {
    icon: Users,
    title: 'Creator Community',
    description:
      'Join thousands of designers, marketers, and creators who trust PikFinder for their visual needs.',
    link: '/contact',
  },
  {
    icon: Sparkle,
    title: 'Premium Collections',
    description:
      'Hand-curated themed collections updated weekly by our creative team for instant inspiration.',
    link: '/collections',
  },
];

const stats = [
  { value: '2M+', label: 'Free Images' },
  { value: '150K+', label: 'Active Creators' },
  { value: '99.9%', label: 'Uptime' },
  { value: '4.9★', label: 'User Rating' },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' } },
};

export default function Products() {
  const [billingCycle, setBillingCycle] = useState('monthly');
  const navigate = useNavigate();
  const { isLoggedIn, toggleAuthModal } = useContext(AppContext);

  const handlePlanClick = (action) => {
    if (action === 'contact') {
      navigate('/contact');
    } else if (action === 'signup') {
      if (isLoggedIn) {
        navigate('/');
      } else {
        toggleAuthModal('signup');
      }
    }
  };

  return (
    <div className="products-page">
      {/* Hero Section */}
      <header className="products-hero">
        <div className="products-hero-glow" />
        <motion.div
          className="products-hero-content"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        >
          <motion.div
            className="badge"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <span className="badge-dot pulse-dot" />
            <span>Our Products & Plans</span>
          </motion.div>
          <h1>
            Unlock the full power of{' '}
            <span className="text-gradient">visual discovery.</span>
          </h1>
          <p>
            From free exploration to enterprise-grade APIs—choose the plan that
            fits your creative ambition.
          </p>

          {/* Stats Bar */}
          <motion.div
            className="products-stats"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {stats.map((s) => (
              <motion.div key={s.label} className="stat-pill" variants={itemVariants}>
                <span className="stat-value">{s.value}</span>
                <span className="stat-label">{s.label}</span>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </header>

      {/* Billing Toggle */}
      <section className="billing-toggle-section">
        <div className="billing-toggle">
          <button
            className={billingCycle === 'monthly' ? 'active' : ''}
            onClick={() => setBillingCycle('monthly')}
          >
            Monthly
          </button>
          <button
            className={billingCycle === 'yearly' ? 'active' : ''}
            onClick={() => setBillingCycle('yearly')}
          >
            Yearly <span className="save-badge">Save 20%</span>
          </button>
        </div>
      </section>

      {/* Pricing Cards */}
      <motion.section
        className="pricing-grid"
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
      >
        {plans.map((plan) => {
          const Icon = plan.icon;
          const displayPrice =
            plan.id === 'free'
              ? '$0'
              : billingCycle === 'yearly'
              ? `$${Math.round(parseInt(plan.price.replace('$', '')) * 0.8)}`
              : plan.price;

          return (
            <motion.div
              key={plan.id}
              className={`pricing-card ${plan.popular ? 'popular' : ''}`}
              variants={itemVariants}
              whileHover={{ y: -8, transition: { duration: 0.3 } }}
            >
              {plan.popular && (
                <div className="popular-ribbon">
                  <Star weight="fill" /> Most Popular
                </div>
              )}

              <div className="pricing-card-icon" style={{ background: plan.gradient }}>
                <Icon size={28} weight="fill" />
              </div>

              <h3>{plan.name}</h3>
              <p className="plan-description">{plan.description}</p>

              <div className="price-display">
                <AnimatePresence mode="wait">
                  <motion.span
                    key={displayPrice}
                    className="price-amount"
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    transition={{ duration: 0.25 }}
                  >
                    {displayPrice}
                  </motion.span>
                </AnimatePresence>
                <span className="price-period">
                  {plan.id === 'free'
                    ? 'forever'
                    : billingCycle === 'yearly'
                    ? '/month, billed yearly'
                    : '/month'}
                </span>
              </div>

              <ul className="feature-list">
                {plan.features.map((f) => (
                  <li key={f}>
                    <CheckCircle weight="fill" style={{ color: plan.accentColor }} />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              <button
                className={`pricing-cta ${plan.popular ? 'cta-primary' : 'cta-outline'}`}
                onClick={() => handlePlanClick(plan.ctaAction)}
              >
                {plan.cta} <ArrowRight />
              </button>
            </motion.div>
          );
        })}
      </motion.section>

      {/* Features Grid */}
      <section className="products-features-section">
        <motion.div
          className="section-header"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2>
            Everything you need to{' '}
            <span className="text-gradient">create without limits.</span>
          </h2>
          <p>
            PikFinder is more than a search engine—it's a creative platform built
            for modern visual storytelling.
          </p>
        </motion.div>

        <motion.div
          className="features-grid"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.15 }}
        >
          {features.map((feat) => {
            const Icon = feat.icon;
            return (
              <motion.div
                key={feat.title}
                className="feature-card"
                variants={itemVariants}
                whileHover={{
                  borderColor: 'rgba(139, 92, 246, 0.4)',
                  transition: { duration: 0.3 },
                }}
                onClick={() => navigate(feat.link)}
                style={{ cursor: 'pointer' }}
              >
                <div className="feature-icon-wrap">
                  <Icon size={28} weight="duotone" />
                </div>
                <h4>{feat.title}</h4>
                <p>{feat.description}</p>
              </motion.div>
            );
          })}
        </motion.div>
      </section>

      {/* CTA Banner */}
      <motion.section
        className="products-cta-banner"
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
      >
        <div className="cta-banner-glow" />
        <div className="cta-banner-content">
          <h2>Ready to elevate your creative workflow?</h2>
          <p>
            Join 150,000+ creators who trust PikFinder for stunning,
            copyright-free visuals.
          </p>
          <div className="cta-banner-actions">
            <button className="btn-primary" onClick={() => handlePlanClick('signup')}>
              <Rocket weight="fill" /> Get Started Free
            </button>
            <button className="btn-outline" onClick={() => navigate('/contact')}>
              Contact Sales
            </button>
          </div>
        </div>
      </motion.section>
    </div>
  );
}
