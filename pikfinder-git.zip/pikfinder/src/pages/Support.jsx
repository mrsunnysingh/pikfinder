import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Coffee, Heart, Sparkle, HandHeart } from '@phosphor-icons/react';

// PayPal.me username & support URL come from .env (kept out of the repo).
// Set VITE_PAYPAL_ME and optionally VITE_SUPPORT_URL in your .env file.
const PAYPAL_ME = import.meta.env.VITE_PAYPAL_ME || '';
const SUPPORT_URL = import.meta.env.VITE_SUPPORT_URL || '';

const TIERS = [
  { emoji: '☕', label: 'A coffee', amount: 3, note: 'Keeps me caffeinated' },
  { emoji: '🍰', label: 'Coffee & cake', amount: 5, note: 'Fuels a late-night fix', featured: true },
  { emoji: '🚀', label: 'Power a feature', amount: 10, note: 'Ships something new' },
];

function donateUrl(amount) {
  if (PAYPAL_ME) {
    const base = `https://paypal.me/${PAYPAL_ME}`;
    return amount && amount > 0 ? `${base}/${amount}` : base;
  }
  return SUPPORT_URL || null;
}

export default function Support() {
  const [amount, setAmount] = useState(5);
  const [custom, setCustom] = useState('');

  const open = (amt) => {
    const url = donateUrl(amt);
    if (url) window.open(url, '_blank', 'noopener,noreferrer');
  };

  const chosen = custom ? Number(custom) : amount;

  return (
    <div className="support-page">
      <div className="support-hero">
        <motion.div
          className="coffee-badge"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 200, damping: 14 }}
        >
          <motion.span
            animate={{ y: [0, -8, 0], rotate: [0, -4, 4, 0] }}
            transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
            style={{ display: 'inline-block', fontSize: '3rem' }}
          >
            ☕
          </motion.span>
        </motion.div>

        <motion.h1 initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          Buy me a coffee
        </motion.h1>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.25 }}>
          Pik Finder is free and always will be. If it saved you time, a small tip helps me keep
          the servers running and ship new tools. Thank you 💜
        </motion.p>
      </div>

      <div className="support-card">
        <div className="tier-row">
          {TIERS.map((t) => (
            <button
              key={t.amount}
              className={`tier-card ${!custom && amount === t.amount ? 'active' : ''} ${t.featured ? 'featured' : ''}`}
              onClick={() => { setAmount(t.amount); setCustom(''); }}
            >
              {t.featured && <span className="tier-flag"><Sparkle weight="fill" /> Popular</span>}
              <span className="tier-emoji">{t.emoji}</span>
              <span className="tier-amount">${t.amount}</span>
              <span className="tier-label">{t.label}</span>
              <span className="tier-note">{t.note}</span>
            </button>
          ))}
        </div>

        <div className="custom-amount">
          <span>Or a custom amount</span>
          <div className="custom-input">
            <span className="dollar">$</span>
            <input
              type="number" min="1" step="1" placeholder="15"
              value={custom}
              onChange={(e) => setCustom(e.target.value)}
            />
          </div>
        </div>

        <motion.button
          className="paypal-btn"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => open(chosen > 0 ? chosen : undefined)}
        >
          <HandHeart weight="fill" /> Support with ${chosen > 0 ? chosen : '—'} via PayPal
        </motion.button>

        {SUPPORT_URL && (
          <div className="support-alt">
            <a href={SUPPORT_URL} target="_blank" rel="noopener noreferrer">
              <Coffee /> Other ways to support
            </a>
          </div>
        )}
      </div>

      <div className="support-footer-line">
        <Heart weight="fill" /> Every tip goes straight into building better free tools for creators.
      </div>
    </div>
  );
}
